# Сквозной трекинг людей по камерам офиса

Команда **ТОКЕНЫ ЗАКОНЧИЛИСЬ**, хакатон NtechLab. Прототип находит людей на записях нескольких камер и ведёт человека одним номером, пока его видит хотя бы одна камера. Организаторы уточнили, что длительное отсутствие значит больше минуты: нет дольше минуты, и трек закрыт, а при возврате будет новый номер.

На предоставленной записи (20 минут, 5 камер) получился **61 сквозной трек**. Перечень с ID, началом, концом и камерами: [results/tracks.csv](results/tracks.csv). Запасной перечень без возвратов по внешности, 91 трек: [results/tracks_without_returns.csv](results/tracks_without_returns.csv). Как это работает, что взято готовым и где алгоритм ошибается: [docs/SOLUTION.md](docs/SOLUTION.md).

![Кадр готовой витрины: камеры, силуэты и план](artifacts/demo/overview.jpg)

**Для показа:** [короткий ролик](render/full/showcase.mp4), [офлайн-отчёт](render/full/report.html), [сценарий на пять минут](docs/DEMO_SCRIPT.md). Для пересборки медиа без нагрузки на ноутбук: [Colab-инструкция](docs/COLAB_DEMO.md) и [блокнот](colab/build_demo.ipynb).

| Критерий | Где проверить |
|---|---|
| Единый ID между камерами | «Треки»: снимки, камеры, таймлайн и связи; мозаика |
| Завершение и возвраты | Сегменты в досье; [трактовка минуты и ограничения](docs/LIMITATIONS.md); просмотр [закрытий](artifacts/test-results/closure_audit.csv) и [возвратов](artifacts/test-results/transition_audit.csv) |
| Перечень треков | `results/tracks.csv`: 61; это число треков, а не доказанное число людей. [Просмотр всех треков](artifacts/test-results/track_audit.csv) |
| Проверки и повторяемость | [Фактические результаты](docs/TEST_RESULTS.md), журналы в `artifacts/test-results` |
| Алгоритм и вклад команды | [Архитектура](docs/ARCHITECTURE.md), [описание решения](docs/SOLUTION.md) |

Ролики и отчёт собраны командой `make all` на ноутбуке без GPU, все 10 проверок и тесты прошли. Подробности и границы проверки — в [результатах тестирования](docs/TEST_RESULTS.md).

## Что нужно

- Windows, Linux или macOS и [uv](https://docs.astral.sh/uv/). Python 3.11 `uv` поставит сам, окружение занимает около 2 ГБ. Команды `make` доступны на Linux/macOS; на всех системах можно использовать `python run.py`.
- На Linux без графического окружения нужна системная библиотека `libgl1`: её требует OpenCV.
- Для демо и пересчёта треков GPU не нужен. Детекции на всей записи нужен GPU: в Colab это около полутора часов.

Репозиторий закрытый и содержит всё: записи и план (`data/`), результат детекции (`artifacts/perception`), треки и снимки (`artifacts/tracks`), ролики и отчёт (`render/full`), веса (`weights/`), ТЗ (`docs/brief/`). В записях и роликах кадры с людьми: не делайте репозиторий открытым и не публикуйте их.

## Запуск демо

```bash
git clone --depth 1 -b mct-pipeline https://github.com/not-man/computer-vision.git
cd computer-vision
make setup
make demo
```

Интерфейс откроется на http://localhost:8501. Перед запуском `make demo` проверяет файлы и не даст начать показ, если что-то не сходится. Ничего не пересчитывается.

На Windows (PowerShell), после клонирования и перехода в папку проекта:

```powershell
python -m pip install uv
python run.py setup
python run.py demo
```

Проверка: `python run.py check`; тесты: `python run.py test`; полный пересчёт после детекции: `python run.py all`. Эти команды работают и на Linux/macOS. Запускатель включает UTF-8 для русских подписей и останавливается при ошибке любого этапа.

| Раздел | Что показывает |
|---|---|
| Витрина | Общее число треков и ролик до 90 с из фрагментов записи |
| Вся запись | Синхронное видео всех камер по минутам, силуэты и номера, события минуты |
| Треки | Таблица и таймлайн всех треков. У выбранного: камеры и время, снимки, связи, путь на плане, видео |
| Возвраты | Похожие пары после отсутствия дольше минуты. Это только подсказки: номера не склеиваются |
| Как проверяли | Устойчивость результата к порогам и правилам, известные ошибки |

Запасной вариант без сервера: откройте `render/full/report.html`. Отчёт открывает ролики из своей папки.

## Пересчёт

```bash
make all
```

Пересчитывает всё после детекции: треки, мозаику, снимки, проверку устойчивости, витрину и отчёт. Нужны `artifacts/perception` и `data/`, GPU не нужен, на ноутбуке это занимает 9–13 минут. На чистой копии репозитория перечень треков совпал побайтно: см. [docs/SOLUTION.md](docs/SOLUTION.md).

Детекцию и ReID запускайте на GPU. Удобнее всего в Colab: `colab/run_perception.ipynb`, архив кода для него собирает `scripts/make_colab_bundle.py`. На своей машине:

```bash
PYTHONPATH=src python scripts/run_perception.py data --out artifacts/perception --device 0 --model yolo11m-seg.pt
```

Веса YOLO и OSNet скачиваются при первом запуске.

## Команды

| Команда | Что делает |
|---|---|
| `make setup` | Ставит окружение без GPU |
| `make demo` | Проверяет файлы и запускает интерфейс |
| `make check` | Только проверка файлов перед показом |
| `make all` | Всё после детекции |
| `make test` | Тесты |

## Зависимости

Список в [pyproject.toml](pyproject.toml), точные версии в [uv.lock](uv.lock). Главные: `ultralytics==8.4.203` (YOLO11m-seg, BoT-SORT), `boxmot==26.0.0` (OSNet-AIN), `opencv-python==4.11.0.86`, `imageio-ffmpeg`, `scipy`, `numpy`, `pandas`, `pyarrow`, `pycocotools`, `pyyaml`, `pillow`, `matplotlib`, `lap`, `streamlit`, `plotly`.

В `pyproject.toml` указана лицензия AGPL-3.0-only.

## Документы

- [docs/SOLUTION.md](docs/SOLUTION.md): краткое описание решения.
- [docs/DESIGN.md](docs/DESIGN.md): подробный проект и измерения на записи.
- [docs/STATUS.md](docs/STATUS.md): текущее состояние работы.
