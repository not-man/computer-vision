"""Строит модель «номер кадра → часы» по сменам секунд наложенных часов и проверяет её.

Метки времени файла использовать нельзя: они идут медленнее часов и раз в 500 с прыгают на 10 с.
"""
import argparse
import json
import subprocess
from pathlib import Path

import numpy as np
import yaml

from mct.video import FFMPEG

# Цифра единиц секунд в исходном кадре 2592×1944: (x, y, ширина, высота)
DIGIT_BOXES = {"camera_new_4": (2520, 40, 44, 52)}
DEFAULT_BOX = (578, 8, 40, 44)


def find_ticks(video: Path, min_delta: float) -> tuple[np.ndarray, int]:
    x, y, w, h = DIGIT_BOXES.get(video.stem, DEFAULT_BOX)
    cmd = [
        FFMPEG, "-v", "fatal", "-threads", "3", "-i", str(video), "-map", "0:v", "-fps_mode", "passthrough",
        "-vf", f"crop={w}:{h}:{x}:{y}", "-pix_fmt", "gray", "-f", "rawvideo", "-",
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    prev, index, deltas = None, 0, []
    while len(buf := proc.stdout.read(w * h)) == w * h:
        frame = np.frombuffer(buf, np.uint8).astype(np.int16)
        if prev is not None:
            deltas.append(float(np.abs(frame - prev).mean()))
        prev = frame
        index += 1
    proc.wait()
    ticks = np.nonzero(np.array(deltas) > min_delta)[0] + 1
    # Смена цифры размазана кодеком на соседние кадры: оставляем первый кадр каждой группы
    return ticks[np.insert(np.diff(ticks) > 3, 0, True)], index


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("video", type=Path)
    parser.add_argument("--out", type=Path, default=Path("artifacts/clocks"))
    parser.add_argument("--min-delta", type=float, default=12.0)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    camera = args.video.stem
    clocks = yaml.safe_load(Path("configs/clocks.yaml").read_text())[camera]
    fps = round(clocks["fps"])
    ticks, frames = find_ticks(args.video, args.min_delta)

    # Фаза смены секунды как круговое среднее: случайные срабатывания на него почти не влияют
    angles = 2 * np.pi * (ticks % fps) / fps
    phase = (np.angle(np.exp(1j * angles).mean()) % (2 * np.pi)) * fps / (2 * np.pi)
    # Устойчивая подгонка: номер смены от кадра, с проверкой, что реальная частота равна номинальной
    seconds = np.round((ticks - phase) / fps)
    residual = ticks - (phase + seconds * fps)
    good = np.abs(residual) <= 2
    slope, intercept = np.polyfit(seconds[good], ticks[good], 1)
    fit_residual = ticks[good] - (intercept + slope * seconds[good])

    # Первая смена после нулевого кадра показывает first + 1
    clock_at_frame_0 = clocks["first"] + 1 - intercept / slope
    predicted_last = clock_at_frame_0 + (frames - 1) / slope
    result = {
        "camera": camera,
        "frames": frames,
        "frames_per_clock_s": round(float(slope), 4),
        "clock_at_frame_0": round(float(clock_at_frame_0), 3),
        "ticks_total": len(ticks),
        "ticks_used": int(good.sum()),
        "fit_residual_frames_p95": round(float(np.percentile(np.abs(fit_residual), 95)), 2),
        "predicted_last_s": round(float(predicted_last), 2),
        "read_last_s": clocks["last"],
    }
    (args.out / f"{camera}_clock.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
