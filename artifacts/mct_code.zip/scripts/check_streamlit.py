"""Проверка показа: видео вне фрагмента не должно перезапускаться при выборе строки внутри него."""
from pathlib import Path

import pandas as pd
import streamlit as st

CHUNKS = sorted(Path("render/check").glob("*.mp4"))

st.set_page_config(layout="wide", page_title="Проверка показа")
choice = st.select_slider("Часть", options=[c.name for c in CHUNKS])
st.video(str(Path("render/check") / choice))


@st.fragment
def track_table() -> None:
    table = pd.DataFrame({"track_id": range(1, 21), "камеры": ["cam_1, cam_2"] * 20})
    selected = st.dataframe(table, on_select="rerun", selection_mode="single-row", key="tracks", height=240)
    rows = selected.selection.rows
    st.write(f"Выбран трек: {table.track_id[rows[0]] if rows else 'нет'}")


track_table()
